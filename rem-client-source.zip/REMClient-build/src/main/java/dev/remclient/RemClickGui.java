package dev.remclient;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class RemClickGui extends Screen {
    // Demon Rem Color Palette
    private static final int BG_OVERLAY = 0xC0000000;
    private static final int PANEL = 0xF5140B22;
    private static final int EDGE = 0xFF9A70C8;
    private static final int TEXT = 0xFFF4EAFB;
    private static final int MUTED = 0xFFBDAACB;
    private static final int ACCENT = 0xFFC084FC;
    private static final int CARD_BG = 0xFF1C102E;
    private static final int CARD_BORDER = 0xFF3D2163;

    // Tabs
    public enum Tab {
        ALL_MODULES,
        KEYBINDS,
        SETTINGS
    }

    private Tab currentTab = Tab.ALL_MODULES;

    // Scroll offset for ALL MODULES list
    private int scrollOffset = 0;
    private static final int ITEM_HEIGHT = 44;

    // Keybind capturing state
    private String listeningModule = null;

    // Module whose settings are shown in the SETTINGS tab
    private String selectedModule = null;
    private static final int SETTING_ROW = 30;

    // Tooltip / feedback notice
    private String feedbackNotice = null;
    private long feedbackExpiry = 0;

    public RemClickGui() {
        super(Component.literal("REM Client"));
    }

    @Override
    protected void init() {
        clearWidgets();
        int panelWidth = Math.min(440, this.width - 20);
        int left = (this.width - panelWidth) / 2;
        int top = Math.max(16, (this.height - 340) / 2);
        int panelHeight = 330;

        // Section Switcher Tabs
        int tabWidth = (panelWidth - 28) / 3;
        int tabY = top + 42;

        addRenderableWidget(Button.builder(Component.literal("ALL MODULES"), b -> {
            currentTab = Tab.ALL_MODULES;
            init();
        }).bounds(left + 14, tabY, tabWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("KEYBINDS"), b -> {
            currentTab = Tab.KEYBINDS;
            init();
        }).bounds(left + 14 + tabWidth + 2, tabY, tabWidth, 20).build());

        addRenderableWidget(Button.builder(Component.literal("SETTINGS"), b -> {
            currentTab = Tab.SETTINGS;
            init();
        }).bounds(left + 14 + (tabWidth + 2) * 2, tabY, tabWidth, 20).build());

        // Close button at bottom
        int buttonWidth = panelWidth - 28;
        addRenderableWidget(Button.builder(Component.literal("CLOSE"), b -> onClose())
            .bounds(left + 14, top + panelHeight - 28, buttonWidth, 20).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        graphics.fill(0, 0, width, height, BG_OVERLAY);

        int panelWidth = Math.min(440, width - 20);
        int panelHeight = 330;
        int left = (width - panelWidth) / 2;
        int top = Math.max(16, (height - panelHeight) / 2);

        // Demon Rem neon purple border & panel background
        graphics.fill(left - 2, top - 2, left + panelWidth + 2, top + panelHeight + 2, EDGE);
        graphics.fill(left, top, left + panelWidth, top + panelHeight, PANEL);

        // Header Title & Branding
        graphics.drawCenteredString(font, "REM CLIENT", width / 2, top + 10, TEXT);
        graphics.drawCenteredString(font, "Demon Rem Interface • Minecraft 1.21.11", width / 2, top + 24, MUTED);

        // Active tab indicator highlight
        int tabWidth = (panelWidth - 28) / 3;
        int tabY = top + 42;
        int activeIdx = currentTab.ordinal();
        graphics.fill(left + 14 + activeIdx * (tabWidth + 2), tabY + 19, left + 14 + (activeIdx + 1) * tabWidth + activeIdx * 2, tabY + 21, ACCENT);

        // Render tab contents
        int contentTop = top + 68;
        int contentBottom = top + panelHeight - 34;

        if (currentTab == Tab.ALL_MODULES) {
            renderAllModulesTab(graphics, left + 14, contentTop, panelWidth - 28, contentBottom - contentTop, mouseX, mouseY);
        } else if (currentTab == Tab.KEYBINDS) {
            renderKeybindsTab(graphics, left + 14, contentTop, panelWidth - 28, contentBottom - contentTop, mouseX, mouseY);
        } else if (currentTab == Tab.SETTINGS) {
            renderSettingsTab(graphics, left + 14, contentTop, panelWidth - 28, contentBottom - contentTop, mouseX, mouseY);
        }

        super.render(graphics, mouseX, mouseY, partialTick);

        // Render temporary feedback toast if active
        if (feedbackNotice != null && System.currentTimeMillis() < feedbackExpiry) {
            int noticeWidth = font.width(feedbackNotice) + 16;
            int nx = (width - noticeWidth) / 2;
            int ny = top + panelHeight - 52;
            graphics.fill(nx, ny, nx + noticeWidth, ny + 18, 0xEE1E0E33);
            graphics.fill(nx, ny, nx + noticeWidth, ny + 1, EDGE);
            graphics.drawCenteredString(font, feedbackNotice, width / 2, ny + 5, ACCENT);
        }
    }

    // TAB 1: ALL MODULES (Scrollable list with Name, ON/OFF toggle, Keybind pill, Settings button)
    private void renderAllModulesTab(GuiGraphics graphics, int x, int y, int w, int h, int mouseX, int mouseY) {
        List<String> modules = RemClient.ALL_MODULE_NAMES;
        int totalContentHeight = modules.size() * ITEM_HEIGHT;
        int maxScroll = Math.max(0, totalContentHeight - h);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));

        graphics.enableScissor(x, y, x + w, y + h);

        int currentY = y - scrollOffset;
        for (String name : modules) {
            if (currentY + ITEM_HEIGHT >= y && currentY <= y + h) {
                renderModuleCard(graphics, x, currentY, w, ITEM_HEIGHT - 6, name, mouseX, mouseY);
            }
            currentY += ITEM_HEIGHT;
        }

        graphics.disableScissor();

        // Scrollbar
        if (maxScroll > 0) {
            int barHeight = Math.max(16, (h * h) / totalContentHeight);
            int barY = y + (scrollOffset * (h - barHeight)) / maxScroll;
            graphics.fill(x + w - 4, y, x + w, y + h, 0x40000000);
            graphics.fill(x + w - 4, barY, x + w, barY + barHeight, EDGE);
        }
    }

    private void renderModuleCard(GuiGraphics graphics, int x, int y, int w, int h, String name, int mouseX, int mouseY) {
        boolean supported = RemClient.isSupported(name);
        boolean enabled = RemClient.isModuleEnabled(name);
        boolean hovered = mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;

        // Card background & border
        graphics.fill(x, y, x + w, y + h, CARD_BG);
        graphics.fill(x, y, x + w, y + 1, hovered ? ACCENT : CARD_BORDER);
        graphics.fill(x, y + h - 1, x + w, y + h, hovered ? ACCENT : CARD_BORDER);
        graphics.fill(x, y, x + 1, y + h, hovered ? ACCENT : CARD_BORDER);
        graphics.fill(x + w - 1, y, x + w, y + h, hovered ? ACCENT : CARD_BORDER);

        // Module Name
        int textColor = supported ? TEXT : 0xFF9E8EAA;
        graphics.drawString(font, name, x + 10, y + 8, textColor, false);

        // Subtitle / category
        String sub = supported ? "Client Module" : "Not implemented yet";
        graphics.drawString(font, sub, x + 10, y + 20, MUTED, false);

        // Right side: Settings gear (if applicable)
        int rightX = x + w - 10;
        if (RemSettings.hasSettings(name)) {
            int gearW = 18;
            int gearX = rightX - gearW;
            boolean gearHover = mouseX >= gearX && mouseX <= gearX + gearW && mouseY >= y + 8 && mouseY <= y + 26;
            graphics.fill(gearX, y + 8, gearX + gearW, y + 26, gearHover ? 0xFF3A1F5E : 0xFF271442);
            graphics.drawString(font, "⚙", gearX + 5, y + 12, ACCENT, false);
            rightX = gearX - 6;
        }

        // Toggle Button
        int btnW = 52;
        int btnX = rightX - btnW;
        int btnY = y + 7;
        int btnH = 20;

        if (supported) {
            int btnBg = enabled ? 0xFF9A70C8 : 0xFF271442;
            int btnBorder = enabled ? 0xFFC084FC : 0xFF45226E;
            int btnText = enabled ? 0xFF140B22 : 0xFFF4EAFB;
            String label = enabled ? "ON" : "OFF";

            graphics.fill(btnX, btnY, btnX + btnW, btnY + btnH, btnBg);
            graphics.fill(btnX, btnY, btnX + btnW, btnY + 1, btnBorder);
            graphics.fill(btnX, btnY + btnH - 1, btnX + btnW, btnY + btnH, btnBorder);
            graphics.fill(btnX, btnY, btnX + 1, btnY + btnH, btnBorder);
            graphics.fill(btnX + btnW - 1, btnY, btnX + btnW, btnY + btnH, btnBorder);

            graphics.drawCenteredString(font, label, btnX + btnW / 2, btnY + 6, btnText);
        } else {
            // Unavailable combat automation badge
            graphics.fill(btnX - 24, btnY, btnX + btnW, btnY + btnH, 0xFF331622);
            graphics.drawCenteredString(font, "UNAVAILABLE", btnX - 24 + (btnW + 24) / 2, btnY + 6, 0xFFD47C8C);
        }

        // Keybind pill badge (if supported)
        if (supported) {
            int key = RemClient.getModuleKey(name);
            String keyStr = RemClient.getKeyName(key);
            int pillW = Math.max(34, font.width(keyStr) + 8);
            int pillX = btnX - pillW - 6;
            graphics.fill(pillX, btnY, pillX + pillW, btnY + btnH, 0xFF180E2B);
            graphics.fill(pillX, btnY, pillX + pillW, btnY + 1, CARD_BORDER);
            graphics.fill(pillX, btnY + btnH - 1, pillX + pillW, btnY + btnH, CARD_BORDER);
            graphics.fill(pillX, btnY, pillX + 1, btnY + btnH, CARD_BORDER);
            graphics.fill(pillX + pillW - 1, btnY, pillX + pillW, btnY + btnH, CARD_BORDER);
            graphics.drawCenteredString(font, keyStr, pillX + pillW / 2, btnY + 6, ACCENT);
        }
    }

    // TAB 2: KEYBINDS (Assign custom keys with "Press any key...", CLEAR, ESC to cancel)
    private void renderKeybindsTab(GuiGraphics graphics, int x, int y, int w, int h, int mouseX, int mouseY) {
        List<String> modules = RemClient.SUPPORTED_MODULES.stream().toList();
        int totalContentHeight = modules.size() * ITEM_HEIGHT;
        int maxScroll = Math.max(0, totalContentHeight - h);
        scrollOffset = Math.max(0, Math.min(scrollOffset, maxScroll));

        graphics.enableScissor(x, y, x + w, y + h);

        int currentY = y - scrollOffset;
        for (String name : modules) {
            if (currentY + ITEM_HEIGHT >= y && currentY <= y + h) {
                renderKeybindCard(graphics, x, currentY, w, ITEM_HEIGHT - 6, name, mouseX, mouseY);
            }
            currentY += ITEM_HEIGHT;
        }

        graphics.disableScissor();
    }

    private void renderKeybindCard(GuiGraphics graphics, int x, int y, int w, int h, String name, int mouseX, int mouseY) {
        graphics.fill(x, y, x + w, y + h, CARD_BG);
        graphics.fill(x, y, x + w, y + 1, CARD_BORDER);
        graphics.fill(x, y + h - 1, x + w, y + h, CARD_BORDER);
        graphics.fill(x, y, x + 1, y + h, CARD_BORDER);
        graphics.fill(x + w - 1, y, x + w, y + h, CARD_BORDER);

        graphics.drawString(font, name, x + 10, y + 12, TEXT, false);

        int btnH = 20;
        int btnY = y + 7;

        // Clear button
        int clearW = 44;
        int clearX = x + w - clearW - 10;
        graphics.fill(clearX, btnY, clearX + clearW, btnY + btnH, 0xFF271442);
        graphics.drawCenteredString(font, "CLEAR", clearX + clearW / 2, btnY + 6, MUTED);

        // Set Key button
        int setW = 86;
        int setX = clearX - setW - 6;
        boolean isListening = name.equals(listeningModule);

        if (isListening) {
            graphics.fill(setX, btnY, setX + setW, btnY + btnH, 0xFF9A70C8);
            graphics.drawCenteredString(font, "Press any key...", setX + setW / 2, btnY + 6, 0xFF140B22);
        } else {
            int key = RemClient.getModuleKey(name);
            String label = key > 0 ? "[" + RemClient.getKeyName(key) + "]" : "SET KEY";
            graphics.fill(setX, btnY, setX + setW, btnY + btnH, 0xFF271442);
            graphics.drawCenteredString(font, label, setX + setW / 2, btnY + 6, key > 0 ? ACCENT : TEXT);
        }
    }

    // TAB 3: SETTINGS (generic per-module settings; open with the gear icon on a module)
    private void renderSettingsTab(GuiGraphics graphics, int x, int y, int w, int h, int mouseX, int mouseY) {
        if (selectedModule == null || !RemSettings.hasSettings(selectedModule)) {
            graphics.drawCenteredString(font, "Click the gear icon on a module to edit its settings.", x + w / 2, y + 24, MUTED);
            return;
        }
        graphics.drawString(font, selectedModule + " settings", x + 4, y + 2, ACCENT, false);

        List<RemSettings.Setting> list = RemSettings.forModule(selectedModule);
        for (int i = 0; i < list.size(); i++) {
            RemSettings.Setting s = list.get(i);
            int ry = y + 16 + i * SETTING_ROW;
            int rh = SETTING_ROW - 4;
            graphics.fill(x, ry, x + w, ry + rh, CARD_BG);
            graphics.fill(x, ry, x + w, ry + 1, CARD_BORDER);
            graphics.fill(x, ry + rh - 1, x + w, ry + rh, CARD_BORDER);
            graphics.fill(x, ry, x + 1, ry + rh, CARD_BORDER);
            graphics.fill(x + w - 1, ry, x + w, ry + rh, CARD_BORDER);
            graphics.drawString(font, s.name, x + 10, ry + 9, TEXT, false);

            int by = ry + 3;
            if (s.bool) {
                int bx = x + w - 12 - 52;
                boolean on = s.value >= 0.5f;
                graphics.fill(bx, by, bx + 52, by + 20, on ? 0xFF9A70C8 : 0xFF271442);
                graphics.drawCenteredString(font, on ? "ON" : "OFF", bx + 26, by + 6, on ? 0xFF140B22 : TEXT);
            } else {
                int plusX = x + w - 12 - 22;
                int minusX = plusX - 70 - 22;
                graphics.fill(minusX, by, minusX + 22, by + 20, 0xFF271442);
                graphics.drawCenteredString(font, "-", minusX + 11, by + 6, TEXT);
                graphics.drawCenteredString(font, s.display(), minusX + 22 + 35, by + 6, ACCENT);
                graphics.fill(plusX, by, plusX + 22, by + 20, 0xFF271442);
                graphics.drawCenteredString(font, "+", plusX + 11, by + 6, TEXT);
            }
        }
    }

    // Input Handling: mouseClicked, mouseScrolled, keyPressed
    @Override
    public boolean mouseClicked(MouseButtonEvent event, boolean isDouble) {
        if (event.button() == 0) { // Left click
            double mx = event.x();
            double my = event.y();

            int panelWidth = Math.min(440, width - 20);
            int panelHeight = 330;
            int left = (width - panelWidth) / 2;
            int top = Math.max(16, (height - panelHeight) / 2);
            int contentTop = top + 68;
            int contentBottom = top + panelHeight - 34;
            int x = left + 14;
            int w = panelWidth - 28;

            if (currentTab == Tab.ALL_MODULES && my >= contentTop && my <= contentBottom && mx >= x && mx <= x + w) {
                int clickedIndex = (int) ((my - contentTop + scrollOffset) / ITEM_HEIGHT);
                List<String> modules = RemClient.ALL_MODULE_NAMES;
                if (clickedIndex >= 0 && clickedIndex < modules.size()) {
                    String name = modules.get(clickedIndex);
                    int itemY = contentTop - scrollOffset + clickedIndex * ITEM_HEIGHT;

                    // Hitbox Viewer gear button
                    if (RemSettings.hasSettings(name)) {
                        int gearX = x + w - 10 - 18;
                        if (mx >= gearX && mx <= gearX + 18 && my >= itemY + 8 && my <= itemY + 26) {
                            selectedModule = name;
                            currentTab = Tab.SETTINGS;
                            init();
                            return true;
                        }
                    }

                    // Toggle button
                    int rightX = RemSettings.hasSettings(name) ? x + w - 10 - 18 - 6 : x + w - 10;
                    int btnX = rightX - 52;
                    if (mx >= btnX && mx <= btnX + 52 && my >= itemY + 7 && my <= itemY + 27) {
                        if (RemClient.isSupported(name)) {
                            RemClient.setModuleEnabled(name, !RemClient.isModuleEnabled(name));
                        } else {
                            showNotice("Not implemented yet.");
                        }
                        return true;
                    }

                    // Keybind pill click -> jump to KEYBINDS tab for this module
                    if (RemClient.isSupported(name)) {
                        int pillW = 34;
                        int pillX = btnX - pillW - 6;
                        if (mx >= pillX && mx <= btnX - 6 && my >= itemY + 7 && my <= itemY + 27) {
                            currentTab = Tab.KEYBINDS;
                            listeningModule = name;
                            init();
                            return true;
                        }
                    }
                }
            } else if (currentTab == Tab.KEYBINDS && my >= contentTop && my <= contentBottom && mx >= x && mx <= x + w) {
                int clickedIndex = (int) ((my - contentTop + scrollOffset) / ITEM_HEIGHT);
                List<String> modules = RemClient.SUPPORTED_MODULES.stream().toList();
                if (clickedIndex >= 0 && clickedIndex < modules.size()) {
                    String name = modules.get(clickedIndex);
                    int itemY = contentTop - scrollOffset + clickedIndex * ITEM_HEIGHT;

                    int clearX = x + w - 44 - 10;
                    int setX = clearX - 86 - 6;

                    // Clear button
                    if (mx >= clearX && mx <= clearX + 44 && my >= itemY + 7 && my <= itemY + 27) {
                        RemClient.setModuleKey(name, -1);
                        listeningModule = null;
                        showNotice("Keybind cleared for " + name);
                        return true;
                    }

                    // Set Key button
                    if (mx >= setX && mx <= setX + 86 && my >= itemY + 7 && my <= itemY + 27) {
                        listeningModule = name;
                        return true;
                    }
                }
            } else if (currentTab == Tab.SETTINGS && selectedModule != null) {
                List<RemSettings.Setting> list = RemSettings.forModule(selectedModule);
                for (int i = 0; i < list.size(); i++) {
                    RemSettings.Setting s = list.get(i);
                    int by = contentTop + 16 + i * SETTING_ROW + 3;
                    if (my < by || my > by + 20) continue;
                    if (s.bool) {
                        int bx = x + w - 12 - 52;
                        if (mx >= bx && mx <= bx + 52) {
                            RemSettings.toggle(s);
                            return true;
                        }
                    } else {
                        int plusX = x + w - 12 - 22;
                        int minusX = plusX - 70 - 22;
                        if (mx >= plusX && mx <= plusX + 22) {
                            RemSettings.adjust(s, 1);
                            return true;
                        }
                        if (mx >= minusX && mx <= minusX + 22) {
                            RemSettings.adjust(s, -1);
                            return true;
                        }
                    }
                }
            }
        }
        return super.mouseClicked(event, isDouble);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (currentTab == Tab.ALL_MODULES || currentTab == Tab.KEYBINDS) {
            scrollOffset -= (int) (verticalAmount * 16);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyEvent event) {
        int keyCode = event.key();

        // If listening for custom key assignment
        if (listeningModule != null) {
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                listeningModule = null;
                showNotice("Key assignment cancelled.");
                return true;
            } else {
                RemClient.setModuleKey(listeningModule, keyCode);
                showNotice("Bound " + listeningModule + " to " + RemClient.getKeyName(keyCode));
                listeningModule = null;
                return true;
            }
        }

        // Right Shift toggles close
        if (keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT) {
            this.onClose();
            return true;
        }

        // ESC closes screen (handled by super)
        return super.keyPressed(event);
    }

    private void showNotice(String msg) {
        feedbackNotice = msg;
        feedbackExpiry = System.currentTimeMillis() + 2500;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
