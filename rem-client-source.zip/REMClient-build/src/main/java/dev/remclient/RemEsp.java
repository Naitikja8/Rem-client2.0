package dev.remclient;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.level.block.entity.BarrelBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.entity.EnderChestBlockEntity;
import net.minecraft.world.level.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.world.level.block.entity.TrappedChestBlockEntity;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * Overlay-style ESP drawn through the HUD callback: Player ESP (boxes + tracers coloured by distance),
 * Storage ESP and Nametags with armor enchants. World coordinates are projected to the screen by hand,
 * so no world-render hooks are needed (first-person view).
 */
public final class RemEsp {
    private RemEsp() {}

    private static final class Cam {
        final Vec3 eye, fwd, right, up;
        final double tanHalfFov, aspect;
        final int w, h;

        Cam(Minecraft mc, LocalPlayer p, float pt, int w, int h) {
            this.w = w;
            this.h = h;
            eye = p.getEyePosition(pt);
            double yaw = Math.toRadians(p.getViewYRot(pt));
            double pitch = Math.toRadians(p.getViewXRot(pt));
            double cp = Math.cos(pitch), sp = Math.sin(pitch), cy = Math.cos(yaw), sy = Math.sin(yaw);
            fwd = new Vec3(-sy * cp, -sp, cy * cp);
            right = new Vec3(-cy, 0, -sy);
            up = right.cross(fwd);
            tanHalfFov = Math.tan(Math.toRadians(mc.options.fov().get()) / 2.0);
            aspect = (double) w / (double) h;
        }

        /** Returns {screenX, screenY} or null when the point is behind the camera. */
        float[] project(Vec3 world) {
            Vec3 d = world.subtract(eye);
            double z = d.dot(fwd);
            if (z < 0.05) return null;
            double x = d.dot(right);
            double y = d.dot(up);
            double nx = x / (z * tanHalfFov * aspect);
            double ny = y / (z * tanHalfFov);
            return new float[] {(float) ((nx * 0.5 + 0.5) * w), (float) ((0.5 - ny * 0.5) * h)};
        }

        /** Screen rectangle {minX, minY, maxX, maxY}, or null if any corner is behind the camera. */
        float[] projectBox(AABB b) {
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE;
            for (int i = 0; i < 8; i++) {
                Vec3 c = new Vec3(
                        (i & 1) == 0 ? b.minX : b.maxX,
                        (i & 2) == 0 ? b.minY : b.maxY,
                        (i & 4) == 0 ? b.minZ : b.maxZ);
                float[] s = project(c);
                if (s == null) return null;
                minX = Math.min(minX, s[0]);
                minY = Math.min(minY, s[1]);
                maxX = Math.max(maxX, s[0]);
                maxY = Math.max(maxY, s[1]);
            }
            return new float[] {minX, minY, maxX, maxY};
        }
    }

    public static void render(GuiGraphics g, Minecraft mc, float pt) {
        boolean playerEsp = RemClient.isModuleEnabled("Player ESP");
        boolean storageEsp = RemClient.isModuleEnabled("Storage ESP");
        boolean nametags = RemClient.isModuleEnabled("Nametags");
        LocalPlayer self = mc.player;
        if (self == null || mc.level == null || (!playerEsp && !storageEsp && !nametags)) return;

        Cam cam = new Cam(mc, self, pt, g.guiWidth(), g.guiHeight());

        if (storageEsp) renderStorage(g, mc, self, cam);

        for (Player p : mc.level.players()) {
            if (p == self || !p.isAlive() || p.isSpectator()) continue;

            double x = Mth.lerp(pt, p.xo, p.getX());
            double y = Mth.lerp(pt, p.yo, p.getY());
            double z = Mth.lerp(pt, p.zo, p.getZ());
            double hw = p.getBbWidth() / 2.0;
            AABB box = new AABB(x - hw, y, z - hw, x + hw, y + p.getBbHeight(), z + hw);
            double dist = cam.eye.distanceTo(new Vec3(x, y + p.getBbHeight() / 2.0, z));

            if (playerEsp && dist <= RemSettings.get("Player ESP", "Max Range")) {
                int color = rangeColor(dist);
                if (RemSettings.on("Player ESP", "Boxes")) {
                    float[] r = cam.projectBox(box);
                    if (r != null) outline(g, (int) r[0], (int) r[1], (int) r[2], (int) r[3], color);
                }
                if (RemSettings.on("Player ESP", "Tracers")) {
                    float[] s = cam.project(box.getCenter());
                    if (s != null) line(g, cam.w / 2f, cam.h, s[0], s[1], color);
                }
            }

            if (nametags && dist <= RemSettings.get("Nametags", "Max Range")) {
                float[] s = cam.project(new Vec3(x, y + p.getBbHeight() + 0.3, z));
                if (s != null) drawNametag(g, mc.font, p, s[0], s[1], dist);
            }
        }
    }

    // ------------------------------------------------------------------ storage

    private static void renderStorage(GuiGraphics g, Minecraft mc, LocalPlayer self, Cam cam) {
        int radius = (int) RemSettings.get("Storage ESP", "Range (chunks)");
        boolean tracers = RemSettings.on("Storage ESP", "Tracers");
        int pcx = self.blockPosition().getX() >> 4;
        int pcz = self.blockPosition().getZ() >> 4;

        for (int cx = pcx - radius; cx <= pcx + radius; cx++) {
            for (int cz = pcz - radius; cz <= pcz + radius; cz++) {
                LevelChunk chunk = mc.level.getChunk(cx, cz);
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    int color = storageColor(be);
                    if (color == 0) continue;
                    AABB box = new AABB(be.getBlockPos());
                    float[] r = cam.projectBox(box);
                    if (r != null) outline(g, (int) r[0], (int) r[1], (int) r[2], (int) r[3], color);
                    if (tracers) {
                        float[] s = cam.project(box.getCenter());
                        if (s != null) line(g, cam.w / 2f, cam.h, s[0], s[1], color);
                    }
                }
            }
        }
    }

    private static int storageColor(BlockEntity be) {
        if (be instanceof TrappedChestBlockEntity) return 0xFFFF4040;
        if (be instanceof ChestBlockEntity) return 0xFFFFA030;
        if (be instanceof EnderChestBlockEntity) return 0xFFB060FF;
        if (be instanceof BarrelBlockEntity) return 0xFFC08040;
        if (be instanceof ShulkerBoxBlockEntity) return 0xFFFF70D0;
        return 0;
    }

    // ------------------------------------------------------------------ nametags

    private static void drawNametag(GuiGraphics g, Font font, Player p, float sx, float sy, double dist) {
        boolean showEnchants = RemSettings.on("Nametags", "Show Enchants");
        boolean showHealth = RemSettings.on("Nametags", "Show Health");

        String title = p.getName().getString();
        if (showHealth) {
            title += String.format(" [%.1f]", p.getHealth() + p.getAbsorptionAmount());
        }
        title += String.format(" %.0fm", dist);

        EquipmentSlot[] slots = {
            EquipmentSlot.MAINHAND, EquipmentSlot.HEAD, EquipmentSlot.CHEST,
            EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.OFFHAND
        };
        List<ItemStack> stacks = new ArrayList<>();
        List<String> texts = new ArrayList<>();
        int maxW = font.width(title);
        for (EquipmentSlot slot : slots) {
            ItemStack st = p.getItemBySlot(slot);
            if (st.isEmpty()) continue;
            String text = showEnchants ? enchantSummary(st) : "";
            stacks.add(st);
            texts.add(text);
            maxW = Math.max(maxW, 20 + font.width(text));
        }

        int rowH = 17;
        int totalW = maxW + 8;
        int totalH = 12 + stacks.size() * rowH;
        int x = (int) sx - totalW / 2;
        int y = (int) sy - totalH;

        g.fill(x, y, x + totalW, y + totalH, 0x90000000);
        g.fill(x, y, x + totalW, y + 1, rangeColor(dist));
        g.drawString(font, title, x + 4, y + 3, 0xFFFFFFFF, true);

        int ry = y + 12;
        for (int i = 0; i < stacks.size(); i++) {
            g.renderItem(stacks.get(i), x + 2, ry);
            g.drawString(font, texts.get(i), x + 20, ry + 4, 0xFFE0C0FF, true);
            ry += rowH;
        }
    }

    private static String enchantSummary(ItemStack stack) {
        var ench = stack.getEnchantments();
        if (ench.isEmpty()) return "";
        List<String> parts = new ArrayList<>();
        for (var entry : ench.entrySet()) {
            int level = entry.getIntValue();
            String full = Enchantment.getFullname(entry.getKey(), level).getString();
            parts.add(abbreviate(full));
        }
        return String.join(", ", parts);
    }

    /** "Protection IV" -> "Prot IV", "Fire Protection IV" -> "FP IV", "Mending" -> "Mend". */
    private static String abbreviate(String full) {
        String[] words = full.split(" ");
        if (words.length == 0) return full;
        String last = words[words.length - 1];
        boolean hasLevel = last.matches("[IVXLC]+|\\d+");
        int nameWords = hasLevel ? words.length - 1 : words.length;
        if (nameWords <= 0) return full;

        StringBuilder name = new StringBuilder();
        if (nameWords == 1) {
            name.append(words[0], 0, Math.min(4, words[0].length()));
        } else {
            for (int i = 0; i < nameWords; i++) {
                if (!words[i].isEmpty()) name.append(Character.toUpperCase(words[i].charAt(0)));
            }
        }
        return hasLevel ? name + " " + last : name.toString();
    }

    // ------------------------------------------------------------------ drawing helpers

    /** Red when close, yellow in the middle, green when far (Near/Far Range settings). */
    private static int rangeColor(double dist) {
        double near = RemSettings.get("Player ESP", "Near Range");
        double far = Math.max(near + 1.0, RemSettings.get("Player ESP", "Far Range"));
        float t = (float) Mth.clamp((dist - near) / (far - near), 0.0, 1.0);
        int r, gr, b;
        if (t < 0.5f) {
            float k = t / 0.5f;
            r = 255;
            gr = (int) Mth.lerp(k, 48, 220);
            b = 48;
        } else {
            float k = (t - 0.5f) / 0.5f;
            r = (int) Mth.lerp(k, 255, 64);
            gr = (int) Mth.lerp(k, 220, 255);
            b = (int) Mth.lerp(k, 48, 96);
        }
        return 0xFF000000 | (r << 16) | (gr << 8) | b;
    }

    private static void outline(GuiGraphics g, int x0, int y0, int x1, int y1, int c) {
        g.fill(x0, y0, x1 + 1, y0 + 1, c);
        g.fill(x0, y1, x1 + 1, y1 + 1, c);
        g.fill(x0, y0, x0 + 1, y1 + 1, c);
        g.fill(x1, y0, x1 + 1, y1 + 1, c);
    }

    private static void line(GuiGraphics g, float x0, float y0, float x1, float y1, int c) {
        float dx = x1 - x0;
        float dy = y1 - y0;
        int steps = (int) Math.min(3000, Math.max(Math.abs(dx), Math.abs(dy)));
        if (steps <= 0) return;
        int sw = g.guiWidth();
        int sh = g.guiHeight();
        for (int i = 0; i <= steps; i++) {
            int px = (int) (x0 + dx * i / steps);
            int py = (int) (y0 + dy * i / steps);
            if (px < 0 || py < 0 || px >= sw || py >= sh) continue;
            g.fill(px, py, px + 1, py + 1, c);
        }
    }
}
