package dev.remclient;

import java.util.*;

/** Per-module numeric / boolean settings shown in the SETTINGS tab and saved to the config. */
public final class RemSettings {
    public static final class Setting {
        public final String module, name;
        public final float min, max, step, def;
        public final boolean bool;
        public float value;

        Setting(String module, String name, float min, float max, float step, float def, boolean bool) {
            this.module = module;
            this.name = name;
            this.min = min;
            this.max = max;
            this.step = step;
            this.def = def;
            this.bool = bool;
            this.value = def;
        }

        public String key() {
            return module + "." + name;
        }

        public String display() {
            if (bool) return value >= 0.5f ? "ON" : "OFF";
            if (step >= 1f) return String.valueOf((int) value);
            if (step < 0.1f) return String.format(Locale.ROOT, "%.2f", value);
            return String.format(Locale.ROOT, "%.1f", value);
        }
    }

    private static final Map<String, List<Setting>> BY_MODULE = new LinkedHashMap<>();
    private static final Map<String, Setting> BY_KEY = new HashMap<>();

    private static void num(String module, String name, float min, float max, float step, float def) {
        add(new Setting(module, name, min, max, step, def, false));
    }

    private static void flag(String module, String name, boolean def) {
        add(new Setting(module, name, 0f, 1f, 1f, def ? 1f : 0f, true));
    }

    private static void add(Setting s) {
        BY_MODULE.computeIfAbsent(s.module, k -> new ArrayList<>()).add(s);
        BY_KEY.put(s.key(), s);
    }

    static {
        num("Hitbox Viewer", "Range (blocks)", 1f, 6f, 0.5f, 3f);

        num("Auto Inventory Totem", "Delay (ticks)", 0f, 10f, 1f, 0f);
        num("Auto Totem", "Delay (ticks)", 0f, 10f, 1f, 0f);

        num("Hitbox Expand", "Size (blocks)", 1f, 8f, 0.5f, 3f);
        num("Reach", "Distance (blocks)", 3f, 6f, 0.1f, 5f);

        num("Auto Crystal", "Place Delay (ticks)", 0f, 10f, 1f, 1f);
        num("Auto Crystal", "Break Delay (ticks)", 0f, 10f, 1f, 1f);
        num("Auto Crystal", "Range", 2f, 6f, 0.5f, 4.5f);

        flag("Mace Swap", "Swap Back", true);
        num("Automace", "Min Fall Height", 1.5f, 30f, 0.5f, 5f);
        num("Automace", "Range", 2f, 6f, 0.5f, 3.5f);

        flag("Player ESP", "Boxes", true);
        flag("Player ESP", "Tracers", true);
        num("Player ESP", "Max Range", 20f, 200f, 10f, 100f);
        num("Player ESP", "Near Range", 3f, 40f, 1f, 12f);
        num("Player ESP", "Far Range", 10f, 120f, 5f, 40f);

        num("Storage ESP", "Range (chunks)", 1f, 12f, 1f, 6f);
        flag("Storage ESP", "Tracers", false);

        num("Trigger Bot", "Delay (ms)", 0f, 500f, 10f, 0f);
        flag("Trigger Bot", "Require Cooldown", true);

        num("Aim Assist", "Prediction (ticks)", 0f, 10f, 0.5f, 2f);
        num("Aim Assist", "Sensitivity (FOV)", 5f, 180f, 5f, 60f);
        num("Aim Assist", "Speed (deg/tick)", 1f, 30f, 1f, 8f);
        num("Aim Assist", "Range", 2f, 8f, 0.5f, 5f);
        flag("Aim Assist", "Only While Attacking", true);

        flag("Perfect Windcharge", "Auto Jump", true);
        num("Perfect Windcharge", "Jump Delay (ticks)", 1f, 10f, 1f, 5f);

        num("Fast XP", "Throws Per Tick", 1f, 20f, 1f, 5f);

        num("Killaura", "Range", 2f, 6f, 0.5f, 4f);
        num("Killaura", "Attacks Per Second", 1f, 20f, 1f, 10f);
        flag("Killaura", "Rotate", true);
        flag("Killaura", "Players Only", true);
        flag("Killaura", "Require Cooldown", false);

        flag("Nametags", "Show Enchants", true);
        flag("Nametags", "Show Health", true);
        num("Nametags", "Max Range", 20f, 200f, 10f, 100f);
    }

    public static boolean hasSettings(String module) {
        return BY_MODULE.containsKey(module);
    }

    public static List<Setting> forModule(String module) {
        return BY_MODULE.getOrDefault(module, List.of());
    }

    public static Collection<Setting> all() {
        return BY_KEY.values();
    }

    public static Setting find(String key) {
        return BY_KEY.get(key);
    }

    public static float get(String module, String name) {
        Setting s = BY_KEY.get(module + "." + name);
        return s == null ? 0f : s.value;
    }

    public static boolean on(String module, String name) {
        return get(module, name) >= 0.5f;
    }

    public static void toggle(Setting s) {
        s.value = s.value >= 0.5f ? 0f : 1f;
        RemClient.saveConfig();
    }

    public static void adjust(Setting s, int dir) {
        float v = s.value + dir * s.step;
        v = Math.round(v / s.step) * s.step;
        v = Math.max(s.min, Math.min(s.max, v));
        s.value = Math.round(v * 100f) / 100f;
        RemClient.saveConfig();
    }

    private RemSettings() {}
}
