package dev.remclient;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

public final class RemClient implements ClientModInitializer {
    public static final String MOD_ID = "remclient";
    private static KeyMapping openMenuKey;
    private static final Logger LOGGER = LoggerFactory.getLogger("REM Client");
    private static boolean rshiftPrev = false;

    // Module definitions (Order preserved in single ALL MODULES section)
    public static final List<String> ALL_MODULE_NAMES = List.of(
        "Coordinates",
        "FPS Counter",
        "HUD",
        "Keystrokes",
        "Hitbox Viewer",
        "Reach Display",
        "Auto Inventory Totem",
        "Auto Totem",
        "Hitbox Expand",
        "Reach",
        "Auto Crystal",
        "Mace Swap",
        "Automace",
        "Player ESP",
        "Storage ESP",
        "Nametags",
        "Trigger Bot",
        "Aim Assist",
        "Killaura",
        "Perfect Windcharge",
        "Fast XP",
        "Auto Elytra Swap",
        "Shield Breaker"
    );

    // Implemented modules (Shield Breaker is still a placeholder). Ordered so the KEYBINDS tab is stable.
    public static final Set<String> SUPPORTED_MODULES = Collections.unmodifiableSet(new LinkedHashSet<>(List.of(
        "Coordinates",
        "FPS Counter",
        "HUD",
        "Keystrokes",
        "Hitbox Viewer",
        "Reach Display",
        "Auto Inventory Totem",
        "Auto Totem",
        "Hitbox Expand",
        "Reach",
        "Auto Crystal",
        "Mace Swap",
        "Automace",
        "Player ESP",
        "Storage ESP",
        "Nametags",
        "Trigger Bot",
        "Aim Assist",
        "Killaura",
        "Perfect Windcharge",
        "Fast XP",
        "Auto Elytra Swap"
    )));

    // Modules that start enabled on a fresh config
    private static final Set<String> DEFAULT_ON = Set.of("Coordinates", "FPS Counter", "HUD", "Keystrokes");

    private static float currentPartial = 0f;

    // Active state map
    public static final Map<String, Boolean> MODULE_STATES = new LinkedHashMap<>();
    // Custom keybinds map (GLFW keycodes, -1 for none)
    public static final Map<String, Integer> MODULE_KEYBINDS = new LinkedHashMap<>();

    // Track previous key states to trigger toggles on press edge
    private static final Map<Integer, Boolean> KEY_DOWN_PREV = new HashMap<>();

    static {
        // Initialize default states (No preset keybind assignments as required)
        for (String name : ALL_MODULE_NAMES) {
            MODULE_STATES.put(name, DEFAULT_ON.contains(name));
            MODULE_KEYBINDS.put(name, -1);
        }
    }

    public static boolean isSupported(String name) {
        return SUPPORTED_MODULES.contains(name);
    }

    public static boolean isModuleEnabled(String name) {
        return isSupported(name) && MODULE_STATES.getOrDefault(name, false);
    }

    public static void setModuleEnabled(String name, boolean enabled) {
        if (!isSupported(name)) return;
        MODULE_STATES.put(name, enabled);

        // Update Hitbox Viewer state in Minecraft engine if available
        if ("Hitbox Viewer".equals(name)) {
            Minecraft client = Minecraft.getInstance();
            if (client.getEntityRenderDispatcher() != null) {
                try {
                    var m = client.getEntityRenderDispatcher().getClass().getMethod("setRenderHitBoxes", boolean.class);
                    m.invoke(client.getEntityRenderDispatcher(), enabled);
                } catch (Throwable ignored) {}
            }
        }
        saveConfig();
    }

    public static int getModuleKey(String name) {
        return MODULE_KEYBINDS.getOrDefault(name, -1);
    }

    public static void setModuleKey(String name, int keyCode) {
        MODULE_KEYBINDS.put(name, keyCode);
        saveConfig();
    }

    public static String getKeyName(int keyCode) {
        if (keyCode <= 0) return "NONE";
        return switch (keyCode) {
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCTRL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCTRL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LALT";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RALT";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPS";
            case GLFW.GLFW_KEY_BACKSPACE -> "BACK";
            case GLFW.GLFW_KEY_ENTER -> "ENTER";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            default -> {
                String str = GLFW.glfwGetKeyName(keyCode, 0);
                yield (str != null && !str.isEmpty()) ? str.toUpperCase(Locale.ROOT) : "KEY " + keyCode;
            }
        };
    }

    @Override
    public void onInitializeClient() {
        LOGGER.info("[REM Client] initializing");
        try {
            loadConfig();
        } catch (Throwable t) {
            LOGGER.error("[REM Client] config load failed", t);
        }
        try {
            RemModules.init();
        } catch (Throwable t) {
            LOGGER.error("[REM Client] module init failed", t);
        }

        // Visible confirmation that the mod loaded
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> client.execute(() -> {
            if (client.player != null) {
                client.player.displayClientMessage(
                    Component.literal("§d[REM Client] §floaded. Press §dRight Shift §fto open the menu."), false);
            }
        }));

        // Right Shift keybinding to open/close Demon Rem GUI
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.remclient.open_menu",
            GLFW.GLFW_KEY_RIGHT_SHIFT,
            KeyMapping.Category.MISC
        ));

        // Client Tick Handler
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            // Right Shift toggle: registered keybinding OR raw key poll (works even if the binding is remapped/conflicted)
            boolean open = false;
            while (openMenuKey.consumeClick()) open = true;
            if (client.getWindow() != null) {
                boolean rs = InputConstants.isKeyDown(client.getWindow(), GLFW.GLFW_KEY_RIGHT_SHIFT);
                if (rs && !rshiftPrev && client.screen == null) open = true;
                rshiftPrev = rs;
            }
            if (open && client.player != null) {
                if (client.screen == null) {
                    client.setScreen(new RemClickGui());
                } else if (client.screen instanceof RemClickGui) {
                    client.setScreen(null);
                }
            }

            // Check custom module keybinds in-game
            if (client.player != null && client.screen == null && client.getWindow() != null) {
                var window = client.getWindow();
                for (String name : SUPPORTED_MODULES) {
                    int key = getModuleKey(name);
                    if (key > 0) {
                        boolean isDown = InputConstants.isKeyDown(window, key);
                        boolean wasDown = KEY_DOWN_PREV.getOrDefault(key, false);
                        if (isDown && !wasDown) {
                            boolean newState = !isModuleEnabled(name);
                            setModuleEnabled(name, newState);
                            client.player.displayClientMessage(
                                Component.literal("§d[REM Client] §f" + name + " is now " + (newState ? "§aON" : "§cOFF")),
                                true
                            );
                        }
                        KEY_DOWN_PREV.put(key, isDown);
                    }
                }
            }
        });

        // Live HUD Rendering
        HudRenderCallback.EVENT.register((guiGraphics, deltaTracker) -> {
            currentPartial = deltaTracker.getGameTimeDeltaPartialTick(true);
            renderHud(guiGraphics);
        });
    }

    private static void renderHud(GuiGraphics graphics) {
        Minecraft client = Minecraft.getInstance();
        if (client.options.hideGui || client.player == null) {
            return;
        }

        // ESP / Nametags overlay (drawn first so the HUD panels sit on top)
        RemEsp.render(graphics, client, currentPartial);

        Font font = client.font;
        int y = 6;

        // 1. HUD Watermark (Demon Rem styled)
        if (isModuleEnabled("HUD")) {
            String text = "REM CLIENT";
            int textWidth = font.width(text);
            graphics.fill(4, y - 2, 4 + textWidth + 8, y + 12, 0x90181024);
            graphics.fill(4, y - 2, 6, y + 12, 0xFF9A70C8);
            graphics.drawString(font, text, 9, y, 0xFFF4EAFB, true);
            y += 18;
        }

        // 2. Live Coordinates (XYZ)
        if (isModuleEnabled("Coordinates")) {
            double px = client.player.getX();
            double py = client.player.getY();
            double pz = client.player.getZ();
            String coords = String.format(Locale.ROOT, "XYZ: %.1f / %.1f / %.1f", px, py, pz);
            int textWidth = font.width(coords);
            graphics.fill(4, y - 2, 4 + textWidth + 8, y + 12, 0x80181024);
            graphics.drawString(font, coords, 8, y, 0xFFF4EAFB, true);
            y += 18;
        }

        // 3. Live FPS Counter
        if (isModuleEnabled("FPS Counter")) {
            String fpsText = client.getFps() + " FPS";
            int textWidth = font.width(fpsText);
            graphics.fill(4, y - 2, 4 + textWidth + 8, y + 12, 0x80181024);
            graphics.drawString(font, fpsText, 8, y, 0xFFBDAACB, true);
            y += 18;
        }

        // 4. Reach Display (Live distance to crosshair target)
        if (isModuleEnabled("Reach Display")) {
            String reachText;
            if (client.crosshairPickEntity != null) {
                double dist = client.player.getEyePosition().distanceTo(client.crosshairPickEntity.position());
                reachText = String.format(Locale.ROOT, "Reach: %.2fm", dist);
            } else {
                reachText = "Reach: None";
            }
            int textWidth = font.width(reachText);
            graphics.fill(4, y - 2, 4 + textWidth + 8, y + 12, 0x80181024);
            graphics.drawString(font, reachText, 8, y, 0xFFC084FC, true);
            y += 18;
        }

        // 5. Keystrokes (WASD and Space key indicators)
        if (isModuleEnabled("Keystrokes")) {
            renderKeystrokes(graphics, client, font);
        }
    }

    private static void renderKeystrokes(GuiGraphics graphics, Minecraft client, Font font) {
        int screenWidth = graphics.guiWidth();
        int keySize = 22;
        int gap = 2;
        int totalWidth = keySize * 3 + gap * 2;
        int startX = screenWidth - totalWidth - 8;
        int startY = 8;

        boolean wDown = client.options.keyUp.isDown();
        boolean aDown = client.options.keyLeft.isDown();
        boolean sDown = client.options.keyDown.isDown();
        boolean dDown = client.options.keyRight.isDown();
        boolean spaceDown = client.options.keyJump.isDown();

        // Row 1: W key
        renderKey(graphics, font, "W", startX + keySize + gap, startY, keySize, keySize, wDown);

        // Row 2: A, S, D keys
        int row2Y = startY + keySize + gap;
        renderKey(graphics, font, "A", startX, row2Y, keySize, keySize, aDown);
        renderKey(graphics, font, "S", startX + keySize + gap, row2Y, keySize, keySize, sDown);
        renderKey(graphics, font, "D", startX + (keySize + gap) * 2, row2Y, keySize, keySize, dDown);

        // Row 3: Spacebar indicator
        int row3Y = row2Y + keySize + gap;
        renderKey(graphics, font, "─────", startX, row3Y, totalWidth, 14, spaceDown);
    }

    private static void renderKey(GuiGraphics graphics, Font font, String label, int x, int y, int width, int height, boolean isDown) {
        int bgColor = isDown ? 0xCC9A70C8 : 0x80181024;
        int borderColor = isDown ? 0xFFF4EAFB : 0xFF9A70C8;
        int textColor = isDown ? 0xFF181024 : 0xFFF4EAFB;

        graphics.fill(x, y, x + width, y + height, bgColor);
        graphics.fill(x, y, x + width, y + 1, borderColor);
        graphics.fill(x, y + height - 1, x + width, y + height, borderColor);
        graphics.fill(x, y, x + 1, y + height, borderColor);
        graphics.fill(x + width - 1, y, x + width, y + height, borderColor);

        int textWidth = font.width(label);
        int textX = x + (width - textWidth) / 2;
        int textY = y + (height - 8) / 2;
        graphics.drawString(font, label, textX, textY, textColor, false);
    }

    // Config Persistence between Minecraft launches
    private static Path getConfigPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("remclient.properties");
    }

    public static void saveConfig() {
        try {
            Properties props = new Properties();
            for (Map.Entry<String, Boolean> entry : MODULE_STATES.entrySet()) {
                props.setProperty("module." + entry.getKey() + ".enabled", entry.getValue().toString());
            }
            for (Map.Entry<String, Integer> entry : MODULE_KEYBINDS.entrySet()) {
                props.setProperty("module." + entry.getKey() + ".key", entry.getValue().toString());
            }
            for (RemSettings.Setting st : RemSettings.all()) {
                props.setProperty("setting." + st.key(), String.valueOf(st.value));
            }

            Path path = getConfigPath();
            if (!Files.exists(path.getParent())) {
                Files.createDirectories(path.getParent());
            }
            try (OutputStream out = Files.newOutputStream(path)) {
                props.store(out, "REM Client Configuration");
            }
        } catch (Exception ignored) {}
    }

    public static void loadConfig() {
        try {
            Path path = getConfigPath();
            if (!Files.exists(path)) return;

            Properties props = new Properties();
            try (InputStream in = Files.newInputStream(path)) {
                props.load(in);
            }

            for (String name : ALL_MODULE_NAMES) {
                String enabledStr = props.getProperty("module." + name + ".enabled");
                if (enabledStr != null && isSupported(name)) {
                    MODULE_STATES.put(name, Boolean.parseBoolean(enabledStr));
                }
                String keyStr = props.getProperty("module." + name + ".key");
                if (keyStr != null) {
                    try {
                        MODULE_KEYBINDS.put(name, Integer.parseInt(keyStr));
                    } catch (NumberFormatException ignored) {}
                }
            }

            // legacy single hitbox range value
            String legacy = props.getProperty("hitbox.range");
            if (legacy != null) {
                RemSettings.Setting hv = RemSettings.find("Hitbox Viewer.Range (blocks)");
                try { if (hv != null) hv.value = Float.parseFloat(legacy); } catch (NumberFormatException ignored) {}
            }
            for (RemSettings.Setting st : RemSettings.all()) {
                String v = props.getProperty("setting." + st.key());
                if (v != null) {
                    try {
                        st.value = Math.max(st.min, Math.min(st.max, Float.parseFloat(v)));
                    } catch (NumberFormatException ignored) {}
                }
            }
        } catch (Exception ignored) {}
    }
}
