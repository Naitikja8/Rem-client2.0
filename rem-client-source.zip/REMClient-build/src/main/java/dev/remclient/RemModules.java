package dev.remclient;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.boss.enderdragon.EndCrystal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.Optional;

/**
 * Logic for all non-visual REM modules. Everything runs from START_CLIENT_TICK (before vanilla
 * keybind handling) plus the Fabric attack/use callbacks. No mixins are required.
 */
public final class RemModules {
    private static int tick = 0;
    private static int attackedTick = -1;

    // totems
    private static boolean hadOffhandTotem = false;
    private static int totemDelay = -1;
    private static int invTotemDelay = -1;

    // swap back (mace)
    private static int swapBackSlot = -1;
    private static int swapBackAt = -1;
    private static boolean swapBackAllowed = false;
    private static int lastMaceTick = -100;

    // wind charge
    private static int windPending = -1;
    private static boolean windJumpHeld = false;
    private static boolean ownThrow = false;

    // killaura / trigger bot
    private static long lastAuraMs = 0;
    private static long lastTrigMs = 0;
    private static boolean auraAimed = false;

    // auto crystal
    private static BlockPos crystalBase = null;
    private static int crystalBaseUntil = -1;
    private static int crystalPlaceAt = 0;
    private static int crystalBreakAt = 0;

    private RemModules() {}

    public static void init() {
        ClientTickEvents.START_CLIENT_TICK.register(RemModules::onTick);

        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            Minecraft mc = Minecraft.getInstance();
            if (player == mc.player && hand == InteractionHand.MAIN_HAND) {
                onAttack(mc, entity);
            }
            return InteractionResult.PASS;
        });

        UseItemCallback.EVENT.register((player, world, hand) -> onUse(player, hand));
    }

    private static boolean on(String module) {
        return RemClient.isModuleEnabled(module);
    }

    // ------------------------------------------------------------------ tick

    private static void onTick(Minecraft mc) {
        tick++;
        LocalPlayer p = mc.player;
        if (p == null || mc.level == null || mc.gameMode == null) {
            windPending = -1;
            windJumpHeld = false;
            return;
        }

        handleSwapBack(p);
        handleWind(mc, p);
        autoInventoryTotem(mc, p);
        autoTotem(mc, p);

        if (mc.screen == null) {
            combat(mc, p);
            aimAssist(mc, p);
            autoCrystal(mc, p);
            fastXp(mc, p);
        }
    }

    // ------------------------------------------------------------------ attack / use hooks

    private static void onAttack(Minecraft mc, Entity target) {
        if (!(target instanceof LivingEntity) || mc.player == null) return;
        LocalPlayer p = mc.player;

        // Auto Elytra Swap: hitting someone while gliding puts the chestplate back on
        if (on("Auto Elytra Swap") && p.isFallFlying()
                && p.getItemBySlot(EquipmentSlot.CHEST).is(Items.ELYTRA)) {
            equipChestplate(mc, p);
        }

        // Mace Swap: swap to the mace when you hit someone
        if (on("Mace Swap") && !p.getMainHandItem().is(Items.MACE)) {
            int slot = findHotbar(p, Items.MACE);
            if (slot >= 0) {
                markSwapBack(p, RemSettings.on("Mace Swap", "Swap Back"));
                select(p, slot);
            }
        }
    }

    private static InteractionResult onUse(Player player, InteractionHand hand) {
        Minecraft mc = Minecraft.getInstance();
        if (ownThrow || player != mc.player || !on("Perfect Windcharge")) return InteractionResult.PASS;
        if (!player.getItemInHand(hand).is(Items.WIND_CHARGE)) return InteractionResult.PASS;
        if (windPending >= 0) return InteractionResult.FAIL;

        if (RemSettings.on("Perfect Windcharge", "Auto Jump") && mc.player.onGround()) {
            mc.options.keyJump.setDown(true);
            windJumpHeld = true;
            windPending = Math.max(1, (int) RemSettings.get("Perfect Windcharge", "Jump Delay (ticks)"));
        } else {
            windPending = 1;
        }
        return InteractionResult.FAIL; // cancel the vanilla throw, we throw straight down ourselves
    }

    // ------------------------------------------------------------------ wind charge

    private static void handleWind(Minecraft mc, LocalPlayer p) {
        if (windJumpHeld) {
            mc.options.keyJump.setDown(false);
            windJumpHeld = false;
        }
        if (windPending > 0) {
            windPending--;
            if (windPending == 0) {
                if (p.getMainHandItem().is(Items.WIND_CHARGE)) {
                    float old = p.getXRot();
                    ownThrow = true;
                    p.setXRot(90f); // the use packet carries this rotation
                    mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
                    p.swing(InteractionHand.MAIN_HAND);
                    p.setXRot(old);
                    ownThrow = false;
                }
                windPending = -1;
            }
        }
    }

    // ------------------------------------------------------------------ totems

    private static void autoInventoryTotem(Minecraft mc, LocalPlayer p) {
        if (!on("Auto Inventory Totem") || !(mc.screen instanceof InventoryScreen)) {
            invTotemDelay = -1;
            return;
        }
        if (p.getOffhandItem().is(Items.TOTEM_OF_UNDYING)) return;
        if (invTotemDelay < 0) invTotemDelay = (int) RemSettings.get("Auto Inventory Totem", "Delay (ticks)");
        if (invTotemDelay > 0) {
            invTotemDelay--;
            return;
        }
        int idx = findInventory(p, Items.TOTEM_OF_UNDYING);
        if (idx >= 0) swapWithOffhand(mc, p, idx);
    }

    private static void autoTotem(Minecraft mc, LocalPlayer p) {
        boolean has = p.getOffhandItem().is(Items.TOTEM_OF_UNDYING);
        boolean popped = hadOffhandTotem && !has;
        hadOffhandTotem = has;

        if (!on("Auto Totem") || has) {
            totemDelay = -1;
            return;
        }
        if (totemDelay < 0 && !(popped || p.getOffhandItem().isEmpty())) return;
        if (mc.screen != null && !(mc.screen instanceof InventoryScreen)) return;

        if (totemDelay < 0) totemDelay = (int) RemSettings.get("Auto Totem", "Delay (ticks)");
        if (totemDelay > 0) {
            totemDelay--;
            return;
        }
        int idx = findInventory(p, Items.TOTEM_OF_UNDYING);
        if (idx >= 0) swapWithOffhand(mc, p, idx);
        totemDelay = -1;
    }

    // ------------------------------------------------------------------ combat

    private static double reach() {
        return on("Reach") ? RemSettings.get("Reach", "Distance (blocks)") : 3.0;
    }

    private static boolean ready(LocalPlayer p) {
        return p.getAttackStrengthScale(0.5f) >= 1.0f;
    }

    private static void combat(Minecraft mc, LocalPlayer p) {
        boolean atkDown = mc.options.keyAttack.isDown();
        boolean ready = ready(p);

        // Reach / Hitbox Expand: while attack is held, hit what the (modified) reach & hitboxes allow
        if (atkDown && (on("Reach") || on("Hitbox Expand")) && mc.crosshairPickEntity == null && ready) {
            Player t = rayTarget(mc, p, reach());
            if (t != null) attack(mc, t);
        }

        // Killaura
        if (on("Killaura")) {
            double range = RemSettings.get("Killaura", "Range");
            LivingEntity t = nearestLiving(mc, p, range, RemSettings.on("Killaura", "Players Only"));
            if (t == null) {
                auraAimed = false;
            } else {
                boolean rotate = RemSettings.on("Killaura", "Rotate");
                if (rotate) aimAt(p, t.getBoundingBox().getCenter());
                long now = System.currentTimeMillis();
                long interval = (long) (1000f / Math.max(1f, RemSettings.get("Killaura", "Attacks Per Second")));
                boolean cdOk = !RemSettings.on("Killaura", "Require Cooldown") || ready;
                // with rotation on, attack one tick after aiming so the server has the new rotation
                if ((!rotate || auraAimed) && cdOk && now - lastAuraMs >= interval) {
                    attack(mc, t);
                    lastAuraMs = now;
                }
                auraAimed = rotate;
            }
        }

        // Trigger Bot
        if (on("Trigger Bot")) {
            Player t = rayTarget(mc, p, reach());
            if (t != null) {
                long now = System.currentTimeMillis();
                boolean cdOk = !RemSettings.on("Trigger Bot", "Require Cooldown") || ready;
                if (cdOk && now - lastTrigMs >= (long) RemSettings.get("Trigger Bot", "Delay (ms)")) {
                    attack(mc, t);
                    lastTrigMs = now;
                }
            }
        }

        // Automace: falling onto someone swaps to the mace and hits
        if (on("Automace") && !p.onGround() && !p.isFallFlying()
                && p.fallDistance >= RemSettings.get("Automace", "Min Fall Height")
                && tick - lastMaceTick >= 5) {
            LivingEntity t = nearestLiving(mc, p, RemSettings.get("Automace", "Range"), true);
            int slot = findHotbar(p, Items.MACE);
            if (t != null && slot >= 0) {
                if (!p.getMainHandItem().is(Items.MACE)) {
                    markSwapBack(p, RemSettings.on("Mace Swap", "Swap Back"));
                    select(p, slot);
                }
                attack(mc, t);
                lastMaceTick = tick;
            }
        }
    }

    private static void aimAssist(Minecraft mc, LocalPlayer p) {
        if (!on("Aim Assist")) return;
        if (RemSettings.on("Aim Assist", "Only While Attacking") && !mc.options.keyAttack.isDown()) return;

        double range = RemSettings.get("Aim Assist", "Range");
        double fov = RemSettings.get("Aim Assist", "Sensitivity (FOV)");
        float speed = RemSettings.get("Aim Assist", "Speed (deg/tick)");
        float pred = RemSettings.get("Aim Assist", "Prediction (ticks)");
        Vec3 eye = p.getEyePosition();

        float bestYaw = 0, bestPitch = 0;
        double bestAngle = fov / 2.0;
        boolean found = false;

        for (Player t : mc.level.players()) {
            if (!validTarget(p, t)) continue;
            Vec3 aim = t.getBoundingBox().getCenter().add(
                    (t.getX() - t.xo) * pred, (t.getY() - t.yo) * pred, (t.getZ() - t.zo) * pred);
            if (eye.distanceTo(aim) > range) continue;
            float[] yp = angles(eye, aim);
            double dyaw = Mth.wrapDegrees(yp[0] - p.getYRot());
            double dpitch = yp[1] - p.getXRot();
            double angle = Math.hypot(dyaw, dpitch);
            if (angle <= bestAngle) {
                bestAngle = angle;
                bestYaw = yp[0];
                bestPitch = yp[1];
                found = true;
            }
        }
        if (!found) return;

        float dy = Mth.wrapDegrees(bestYaw - p.getYRot());
        float dp = bestPitch - p.getXRot();
        float stepY = Mth.clamp(dy * 0.5f, -speed, speed);
        float stepP = Mth.clamp(dp * 0.5f, -speed, speed);
        p.setYRot(p.getYRot() + stepY);
        p.setXRot(Mth.clamp(p.getXRot() + stepP, -90f, 90f));
    }

    private static void autoCrystal(Minecraft mc, LocalPlayer p) {
        if (!on("Auto Crystal")) {
            crystalBase = null;
            crystalBaseUntil = -1;
            return;
        }
        int slot = findHotbar(p, Items.END_CRYSTAL);
        HitResult hr = mc.hitResult;
        if (slot >= 0 && hr instanceof BlockHitResult bhr && hr.getType() == HitResult.Type.BLOCK) {
            BlockState st = mc.level.getBlockState(bhr.getBlockPos());
            if (st.is(Blocks.OBSIDIAN) || st.is(Blocks.BEDROCK)) {
                crystalBase = bhr.getBlockPos();
                crystalBaseUntil = tick + 20;
                if (!p.getMainHandItem().is(Items.END_CRYSTAL)) select(p, slot);
            }
        }
        if (crystalBase == null || tick > crystalBaseUntil) return;

        double range = RemSettings.get("Auto Crystal", "Range");
        BlockPos above = crystalBase.above();

        // break
        List<EndCrystal> crystals = mc.level.getEntitiesOfClass(EndCrystal.class, new AABB(above).inflate(2.0));
        EndCrystal nearest = null;
        double nd = Double.MAX_VALUE;
        for (EndCrystal c : crystals) {
            double d = p.distanceToSqr(c);
            if (d <= range * range && d < nd) {
                nd = d;
                nearest = c;
            }
        }
        if (nearest != null) {
            if (tick >= crystalBreakAt) {
                attack(mc, nearest);
                crystalBreakAt = tick + (int) RemSettings.get("Auto Crystal", "Break Delay (ticks)");
            }
            return;
        }

        // place
        if (slot < 0 || tick < crystalPlaceAt) return;
        if (!mc.level.getBlockState(above).isAir() || !mc.level.getBlockState(above.above()).isAir()) return;
        if (p.getEyePosition().distanceToSqr(Vec3.atCenterOf(crystalBase)) > range * range) return;
        if (!p.getMainHandItem().is(Items.END_CRYSTAL)) select(p, slot);

        BlockHitResult hit = new BlockHitResult(
                Vec3.atCenterOf(crystalBase).add(0, 0.5, 0), Direction.UP, crystalBase, false);
        InteractionResult r = mc.gameMode.useItemOn(p, InteractionHand.MAIN_HAND, hit);
        if (r.consumesAction()) p.swing(InteractionHand.MAIN_HAND);
        crystalPlaceAt = tick + (int) RemSettings.get("Auto Crystal", "Place Delay (ticks)");
    }

    private static void fastXp(Minecraft mc, LocalPlayer p) {
        if (!on("Fast XP") || !mc.options.keyUse.isDown()) return;
        int n = (int) RemSettings.get("Fast XP", "Throws Per Tick");
        for (int i = 0; i < n; i++) {
            if (!p.getMainHandItem().is(Items.EXPERIENCE_BOTTLE)) break;
            mc.gameMode.useItem(p, InteractionHand.MAIN_HAND);
            p.swing(InteractionHand.MAIN_HAND);
        }
    }

    // ------------------------------------------------------------------ swap back

    private static void markSwapBack(LocalPlayer p, boolean allowed) {
        if (swapBackAt < 0) {
            swapBackSlot = p.getInventory().getSelectedSlot();
            swapBackAllowed = allowed;
        }
        swapBackAt = tick + 6;
    }

    private static void handleSwapBack(LocalPlayer p) {
        if (swapBackAt >= 0 && tick >= swapBackAt) {
            if (swapBackAllowed && swapBackSlot >= 0) select(p, swapBackSlot);
            swapBackAt = -1;
            swapBackSlot = -1;
        }
    }

    // ------------------------------------------------------------------ targeting helpers

    private static boolean validTarget(LocalPlayer self, Player t) {
        return t != self && t.isAlive() && !t.isSpectator();
    }

    /** Player hitbox, inflated when Hitbox Expand is on. */
    public static AABB hitbox(Entity e) {
        AABB b = e.getBoundingBox();
        if (e instanceof Player && on("Hitbox Expand")) {
            double size = RemSettings.get("Hitbox Expand", "Size (blocks)");
            double inflate = Math.max(0.0, (size - 0.6) / 2.0);
            b = b.inflate(inflate);
        }
        return b;
    }

    private static Player rayTarget(Minecraft mc, LocalPlayer p, double reach) {
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getViewVector(1.0f).scale(reach));
        Player best = null;
        double bestD = Double.MAX_VALUE;
        for (Player t : mc.level.players()) {
            if (!validTarget(p, t)) continue;
            AABB box = hitbox(t);
            double d;
            if (box.contains(eye)) {
                d = 0;
            } else {
                Optional<Vec3> hit = box.clip(eye, end);
                if (hit.isEmpty()) continue;
                d = eye.distanceToSqr(hit.get());
            }
            if (d < bestD) {
                bestD = d;
                best = t;
            }
        }
        return best;
    }

    private static LivingEntity nearestLiving(Minecraft mc, LocalPlayer p, double range, boolean playersOnly) {
        AABB area = p.getBoundingBox().inflate(range + 8.0);
        List<Entity> list = mc.level.getEntities(p, area, e ->
                e instanceof LivingEntity le && le.isAlive() && !(e instanceof ArmorStand)
                        && !e.isSpectator() && (!playersOnly || e instanceof Player));
        Vec3 eye = p.getEyePosition();
        LivingEntity best = null;
        double bestD = range * range;
        for (Entity e : list) {
            double d = hitbox(e).distanceToSqr(eye);
            if (d <= bestD) {
                bestD = d;
                best = (LivingEntity) e;
            }
        }
        return best;
    }

    private static float[] angles(Vec3 from, Vec3 to) {
        Vec3 d = to.subtract(from);
        float yaw = (float) Math.toDegrees(Math.atan2(-d.x, d.z));
        float pitch = (float) -Math.toDegrees(Math.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)));
        return new float[] {yaw, pitch};
    }

    private static void aimAt(LocalPlayer p, Vec3 target) {
        float[] yp = angles(p.getEyePosition(), target);
        p.setYRot(yp[0]);
        p.setXRot(Mth.clamp(yp[1], -90f, 90f));
    }

    private static void attack(Minecraft mc, Entity target) {
        if (attackedTick == tick) return;
        attackedTick = tick;
        mc.gameMode.attack(mc.player, target);
        mc.player.swing(InteractionHand.MAIN_HAND);
    }

    // ------------------------------------------------------------------ inventory helpers

    private static void select(LocalPlayer p, int slot) {
        p.getInventory().setSelectedSlot(slot);
    }

    private static int findHotbar(LocalPlayer p, Item item) {
        Inventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(item)) return i;
        }
        return -1;
    }

    /** Index 0-35 into the player inventory; main inventory first, hotbar last. */
    private static int findInventory(LocalPlayer p, Item item) {
        Inventory inv = p.getInventory();
        for (int i = 9; i < 36; i++) {
            if (inv.getItem(i).is(item)) return i;
        }
        for (int i = 0; i < 9; i++) {
            if (inv.getItem(i).is(item)) return i;
        }
        return -1;
    }

    private static int invToMenu(int invIndex) {
        return invIndex < 9 ? invIndex + 36 : invIndex;
    }

    private static void swapWithOffhand(Minecraft mc, LocalPlayer p, int invIndex) {
        mc.gameMode.handleInventoryMouseClick(
                p.inventoryMenu.containerId, invToMenu(invIndex), 40, ClickType.SWAP, p);
    }

    private static void equipChestplate(Minecraft mc, LocalPlayer p) {
        Inventory inv = p.getInventory();
        int idx = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getItem(i);
            if (s.is(ItemTags.CHEST_ARMOR)) {
                idx = i;
                break;
            }
        }
        if (idx < 0) return;
        int slot = invToMenu(idx);
        int id = p.inventoryMenu.containerId;
        // pick up chestplate, drop it on the chest armor slot (6), put the elytra back where it was
        mc.gameMode.handleInventoryMouseClick(id, slot, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, 6, 0, ClickType.PICKUP, p);
        mc.gameMode.handleInventoryMouseClick(id, slot, 0, ClickType.PICKUP, p);
    }
}
