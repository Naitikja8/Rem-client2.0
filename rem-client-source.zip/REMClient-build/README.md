# REM Client (anti-cheat test build)

Fabric client mod for Minecraft 1.21.11. Build with `./gradlew build`; the jar is in `build/libs/`.
Open the menu with Right Shift. Click the gear on a module to edit its settings; bind keys in KEYBINDS.

Modules are all OFF by default except the HUD ones. Use only on servers you own / have permission to test.

Notes
- ESP / Nametags are a 2D overlay (first-person view). FOV sprint effects can shift boxes slightly.
- Reach / Hitbox Expand are applied client-side to attack targeting; the server's own checks decide what lands.
- Perfect Windcharge throws straight down at your feet; launch height is decided by the server.
- Shield Breaker is still a placeholder.
